<template>
  <div class="dashboard-container">

    <div class="card shadow-sm mb-4 map-card border-0">
      <div class="card-header bg-transparent border-bottom-0 pt-4 pb-2 d-flex justify-content-between align-items-center flex-wrap">
        <h4 class="m-0 fw-bold text-primary">
          <i class="bi bi-globe-americas me-2"></i>全球心血管疾病(CVD)死亡率分布图
          <span class="fs-6 text-muted ms-2 fw-normal">数据来源: WHO / GBD (每10万人)</span>
        </h4>
        <div class="btn-group mt-2 mt-md-0" role="group">
          <button v-for="mode in modes" :key="mode.id" type="button" :class="['btn', currentMode === mode.id ? 'btn-primary' : 'btn-outline-primary']" @click="switchMode(mode.id)">
            {{ mode.name }}
          </button>
        </div>
      </div>
      <div class="card-body">
        <div v-if="mapLoading" class="text-center py-5 text-muted">
          <span class="spinner-border spinner-border-sm me-2"></span>正在加载全球地图与WHO权威数据...
        </div>
        <div v-if="mapError" class="alert alert-danger text-center">地图加载失败，请检查网络连接。</div>
        <div id="global-map" style="width: 100%; height: 500px;" v-show="!mapLoading && !mapError"></div>
      </div>
    </div>

    <div class="row g-4 mb-4">
      <div class="col-lg-7">
        <div class="card shadow-sm h-100 border-0 info-card">
          <div class="card-header bg-transparent border-bottom-0 pt-4 pb-2">
            <h4 class="m-0 fw-bold text-danger"><i class="bi bi-heart-pulse-fill me-2"></i>3D 动态心脏结构模型</h4>
            <small class="text-muted">您可以按住鼠标左键旋转、滚轮缩放查看心脏全方位结构</small>
          </div>
          <div class="card-body p-0 position-relative" style="height: 450px; background-color: #111;">
            <iframe title="Realistic Human Heart" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" src="https://sketchfab.com/models/97f61d76780d4a81a8247e1fe7a2d43e/embed?autostart=1&ui_theme=dark" style="width: 100%; height: 100%; border-radius: 0 0 12px 12px;"></iframe>
          </div>
        </div>
      </div>
      <div class="col-lg-5">
        <div class="card shadow-sm h-100 border-0 info-card">
          <div class="card-header bg-transparent border-bottom-0 pt-4 pb-2">
            <h4 class="m-0 fw-bold text-primary"><i class="bi bi-clipboard2-pulse me-2"></i>病理性变态特征分析</h4>
          </div>
          <div class="card-body d-flex flex-column">
            <div class="d-flex flex-wrap gap-2 mb-4">
              <button v-for="(disease, key) in diseaseAnalysis" :key="key" @click="activeDisease = key" :class="['btn btn-sm fw-bold rounded-pill px-3', activeDisease === key ? 'btn-primary' : 'btn-outline-secondary']">
                {{ disease.name }}
              </button>
            </div>
            <div class="disease-detail-box p-4 flex-grow-1 rounded-3">
              <h5 class="fw-bold text-danger mb-3">{{ diseaseAnalysis[activeDisease].name }}</h5>
              <p class="text-muted mb-3" style="font-size: 0.95rem; line-height: 1.6;">
                <strong><i class="bi bi-info-circle-fill text-info me-1"></i>疾病概述：</strong><br>{{ diseaseAnalysis[activeDisease].overview }}
              </p>
              <div class="alert custom-alert border-0 mb-0">
                <p class="mb-2 text-dark fw-bold"><i class="bi bi-search me-1"></i>3D 结构受损表现：</p>
                <ul class="mb-0 text-muted ps-3" style="font-size: 0.9rem;">
                  <li v-for="(item, index) in diseaseAnalysis[activeDisease].lesions" :key="index" class="mb-1">{{ item }}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="card shadow-sm mb-4 border-0 info-card">
      <div class="card-header bg-transparent border-bottom-0 pt-4 pb-2">
        <h4 class="m-0 fw-bold text-dark"><i class="bi bi-sliders me-2 text-warning"></i>AI 风险因子动态推演沙盘</h4>
        <small class="text-muted">基于您的物理指标集 (sysBP, totChol, Age 等) 进行逻辑回归权重的可视化模拟推演</small>
      </div>
      <div class="card-body">
        <div class="row align-items-center">
          <div class="col-md-7 pe-md-5">
            <div class="simulator-panel p-4 rounded-3">
              <div class="mb-4">
                <div class="d-flex justify-content-between mb-1">
                  <label class="fw-bold">年龄 (Age)</label>
                  <span class="text-primary fw-bold">{{ simData.age }} 岁</span>
                </div>
                <input type="range" class="form-range custom-range" min="20" max="90" step="1" v-model="simData.age" @input="updateSimulation">
              </div>
              <div class="mb-4">
                <div class="d-flex justify-content-between mb-1">
                  <label class="fw-bold">收缩压 (sysBP)</label>
                  <span class="text-danger fw-bold">{{ simData.sysBP }} mmHg</span>
                </div>
                <input type="range" class="form-range custom-range-danger" min="90" max="200" step="1" v-model="simData.sysBP" @input="updateSimulation">
              </div>
              <div class="mb-4">
                <div class="d-flex justify-content-between mb-1">
                  <label class="fw-bold">总胆固醇 (totChol)</label>
                  <span class="text-warning fw-bold">{{ simData.chol }} mg/dL</span>
                </div>
                <input type="range" class="form-range custom-range-warning" min="130" max="350" step="1" v-model="simData.chol" @input="updateSimulation">
              </div>
              <div class="mb-0">
                <div class="d-flex justify-content-between mb-1">
                  <label class="fw-bold">日吸烟量 (cigsPerDay)</label>
                  <span class="text-secondary fw-bold">{{ simData.cigs }} 支</span>
                </div>
                <input type="range" class="form-range custom-range-secondary" min="0" max="50" step="1" v-model="simData.cigs" @input="updateSimulation">
              </div>
            </div>
          </div>
          <div class="col-md-5">
            <div id="risk-gauge" style="width: 100%; height: 350px;"></div>
          </div>
        </div>
      </div>
    </div>

    <div class="row g-4">
      <div class="col-md-6">
        <div class="card shadow-sm h-100 border-0 info-card">
          <div class="card-body p-4">
            <h4 class="mb-3 fw-bold text-dark">心脏病的危害</h4>
            <p class="text-muted mb-4">心血管疾病（CVD）是全球第一大死因，每年夺走近 1800 万人的生命。这些疾病可能导致胸痛、呼吸困难、心悸等症状，严重时甚至会危及生命。</p>
            <div class="alert alert-dark border-0 custom-alert">据世界卫生组织统计，超过四分之三的心血管疾病死亡发生在低收入和中等收入国家。</div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card shadow-sm h-100 border-0 info-card">
          <div class="card-body p-4">
            <h4 class="mb-4 fw-bold text-dark">预防心脏病的关键要点</h4>
            <h6 class="text-primary mb-2 fw-bold"><i class="bi bi-apple me-2"></i>健康饮食</h6>
            <ul class="text-muted mb-4 fs-7 ps-3">
              <li><strong>控制脂肪：</strong>减少饱和脂肪和反式脂肪的摄入，如动物内脏、油炸食品等</li>
              <li><strong>控制盐摄入：</strong>建议每天盐的摄入量不超过6克</li>
            </ul>
            <h6 class="text-primary mb-2 fw-bold"><i class="bi bi-bicycle me-2"></i>适量运动</h6>
            <ul class="text-muted mb-0 fs-7 ps-3">
              <li><strong>有氧运动：</strong>如快走、跑步、游泳等，每周至少150分钟</li>
              <li><strong>日常习惯：</strong>减少久坐时间，保持规律作息</li>
            </ul>
          </div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
import * as echarts from 'echarts'
import { ref, reactive, onMounted, onBeforeUnmount, markRaw, nextTick } from 'vue'

export default {
  name: 'Dashboard',
  setup() {
    // ================== 地图逻辑 ==================
    let mapChart = null
    const mapLoading = ref(true)
    const mapError = ref(false)
    const modes = [
      { id: 'cvd', name: '总心血管病死亡率' },
      { id: 'chd', name: '冠心病分布' },
      { id: 'stroke', name: '脑卒中分布' }
    ]
    const currentMode = ref('cvd')
    const whoData = {
      cvd: [{ name: 'Russia', value: 430 }, { name: 'China', value: 277 }, { name: 'United States of America', value: 151 }, { name: 'India', value: 282 }, { name: 'Japan', value: 90 }],
      chd: [{ name: 'Russia', value: 250 }, { name: 'China', value: 100 }, { name: 'India', value: 150 }, { name: 'United States of America', value: 90 }, { name: 'Japan', value: 35 }],
      stroke: [{ name: 'Russia', value: 150 }, { name: 'China', value: 150 }, { name: 'India', value: 75 }, { name: 'United States of America', value: 35 }, { name: 'Japan', value: 40 }]
    }

    const initMap = async () => {
      try {
        // 🚀 核心修复：换成国内阿里巴巴的 NPM 镜像源，告别网络拥堵！
        const response = await fetch('https://registry.npmmirror.com/echarts/4.9.0/files/map/json/world.json')
        if (!response.ok) throw new Error('网络请求失败')
        const worldJson = await response.json()
        echarts.registerMap('world', worldJson)
        mapLoading.value = false
        await nextTick()
        mapChart = markRaw(echarts.init(document.getElementById('global-map')))
        renderMap()
      } catch (error) {
        console.error('地图加载失败:', error)
        mapLoading.value = false
        mapError.value = true
      }
    }

    const renderMap = () => {
      if (!mapChart) return
      let maxVal = 500; let colorRange = ['#fee0d2', '#de2d26'];
      if (currentMode.value === 'chd') { maxVal = 300; colorRange = ['#fff5eb', '#d94801']; }
      else if (currentMode.value === 'stroke') { maxVal = 200; colorRange = ['#f7fbff', '#08519c']; }

      mapChart.setOption({
        tooltip: { trigger: 'item', backgroundColor: 'rgba(15, 23, 42, 0.9)', textStyle: { color: '#fff' } },
        visualMap: { min: 0, max: maxVal, text: ['高危', '低危'], calculable: true, inRange: { color: colorRange }, bottom: 20, left: 20, textStyle: { color: document.documentElement.getAttribute('data-theme') === 'dark' ? '#cbd5e1' : '#334155' } },
        series: [{ type: 'map', map: 'world', zoom: 1.2, roam: true, itemStyle: { areaColor: '#e2e8f0', borderColor: '#94a3b8', borderWidth: 1 }, emphasis: { itemStyle: { areaColor: '#f59e0b' } }, data: whoData[currentMode.value] }]
      })
    }
    const switchMode = (modeId) => { currentMode.value = modeId; renderMap(); }

    // ================== 3D 疾病逻辑 ==================
    const activeDisease = ref('coronary')
    const diseaseAnalysis = {
      coronary: { name: '冠状动脉粥样硬化 (冠心病)', overview: '由于脂质在冠状动脉内膜沉积，形成粥样斑块，导致血管腔狭窄甚至阻塞。', lesions: ['🔴 冠状动脉出现黄色脂质条纹。', '🔴 晚期斑块破裂形成血栓。', '🔴 局部心肌萎缩纤维化。'] },
      hypertension: { name: '高血压性心脏病', overview: '长期体循环动脉血压升高，增加了心脏泵血的阻力，导致左心室代偿性肥大。', lesions: ['🔴 左心室壁明显增厚。', '🔴 晚期心室腔严重扩张。', '🔴 心肌微血管密度降低。'] },
      infarction: { name: '急性心肌梗死', overview: '冠状动脉急性闭塞，导致心肌因严重持久的缺血而发生局部坏死。', lesions: ['🔴 心肌肉眼下呈现不规则苍白。', '🔴 梗死灶周围伴有暗红色出血带。', '🔴 严重者心室壁软化破裂。'] }
    }

    // ================== 动态推演沙盘逻辑 ==================
    let gaugeChart = null
    const simData = reactive({
      age: 45,
      sysBP: 120,
      chol: 200,
      cigs: 0
    })

    const calculateRisk = () => {
      let baseRisk = 5;
      baseRisk += (simData.age - 45) * 0.5;
      baseRisk += (simData.sysBP - 120) * 0.4;
      baseRisk += (simData.chol - 200) * 0.2;
      baseRisk += simData.cigs * 0.8;
      let finalRisk = Math.max(0, Math.min(100, baseRisk));
      return parseFloat(finalRisk.toFixed(1));
    }

    const initGauge = () => {
      gaugeChart = markRaw(echarts.init(document.getElementById('risk-gauge')))
      updateGauge()
    }

    const updateGauge = () => {
      if (!gaugeChart) return;
      const riskValue = calculateRisk();
      const isDark = document.documentElement.getAttribute('data-theme') === 'dark'

      gaugeChart.setOption({
        series: [{
          type: 'gauge',
          startAngle: 210, endAngle: -30,
          min: 0, max: 100,
          splitNumber: 4,
          axisLine: { lineStyle: { width: 18, color: [[0.3, '#34d399'], [0.7, '#fbbf24'], [1, '#ef4444']] } },
          pointer: { icon: 'path://M12.8,0.7l12,40.1H0.7L12.8,0.7z', length: '65%', width: 8, offsetCenter: [0, '-10%'], itemStyle: { color: isDark ? '#e2e8f0' : '#475569' } },
          axisTick: { length: 12, lineStyle: { color: 'auto', width: 2 } },
          splitLine: { length: 20, lineStyle: { color: 'auto', width: 4 } },
          axisLabel: { color: isDark ? '#cbd5e1' : '#64748b', fontSize: 14, distance: -60 },
          title: { offsetCenter: [0, '40%'], fontSize: 16, color: isDark ? '#94a3b8' : '#64748b' },
          detail: { fontSize: 36, offsetCenter: [0, '70%'], valueAnimation: true, formatter: function (value) { return value + '{unit| %}'; }, color: 'inherit', rich: { unit: { fontSize: 18, padding: [0, 0, -10, 2], color: isDark ? '#94a3b8' : '#64748b' } } },
          data: [{ value: riskValue, name: 'AI 综合发病概率' }]
        }]
      })
    }

    const updateSimulation = () => { updateGauge(); }

    onMounted(async () => {
      await initMap()
      initGauge()
      window.addEventListener('resize', () => {
        if(mapChart) mapChart.resize()
        if(gaugeChart) gaugeChart.resize()
      })
      const observer = new MutationObserver(() => updateGauge())
      observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] })
    })

    onBeforeUnmount(() => {
      if (mapChart) mapChart.dispose()
      if (gaugeChart) gaugeChart.dispose()
    })

    return { modes, currentMode, switchMode, mapLoading, mapError, activeDisease, diseaseAnalysis, simData, updateSimulation }
  }
}
</script>

<style scoped>
.dashboard-container { max-width: 1400px; margin: 0 auto; }
.map-card, .info-card { border-radius: 12px; overflow: hidden; }
.fs-7 { font-size: 0.9rem; }
.custom-alert { background-color: rgba(148, 163, 184, 0.1); border-radius: 8px; }
.disease-detail-box { background-color: rgba(59, 130, 246, 0.05); border: 1px solid rgba(59, 130, 246, 0.1); transition: all 0.3s ease; }

.simulator-panel { background-color: rgba(241, 245, 249, 0.5); border: 1px dashed #cbd5e1; }
.form-range { height: 6px; border-radius: 5px; outline: none; transition: 0.2s; }
.form-range::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 18px; height: 18px; border-radius: 50%; background: #3b82f6; cursor: pointer; transition: 0.2s; }
.form-range::-webkit-slider-thumb:hover { transform: scale(1.2); }
.custom-range-danger::-webkit-slider-thumb { background: #ef4444; }
.custom-range-warning::-webkit-slider-thumb { background: #f59e0b; }
.custom-range-secondary::-webkit-slider-thumb { background: #64748b; }

[data-theme="dark"] .map-card, [data-theme="dark"] .info-card { background-color: #1e293b !important; color: #f1f5f9 !important; border-color: #334155 !important; }
[data-theme="dark"] .custom-alert { background-color: rgba(15, 23, 42, 0.6) !important; }
[data-theme="dark"] .disease-detail-box { background-color: rgba(15, 23, 42, 0.4) !important; border-color: #334155 !important; }
[data-theme="dark"] .text-muted { color: #94a3b8 !important; }
[data-theme="dark"] .text-dark { color: #f1f5f9 !important; }
[data-theme="dark"] .simulator-panel { background-color: rgba(15, 23, 42, 0.5) !important; border-color: #475569 !important; }
</style>